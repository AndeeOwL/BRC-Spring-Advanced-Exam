package com.andreanbuhchev.bulgarian_racing_community.model.entity.enums;

public enum VehicleType {
    CAR,MOTORCYCLE
}
