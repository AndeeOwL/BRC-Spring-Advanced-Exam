package com.andreanbuhchev.bulgarian_racing_community.model.entity.enums;

public enum EngineType {
    PETROL,DIESEL,ELECTRIC
}
