package com.andreanbuhchev.bulgarian_racing_community;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BulgarianRacingCommunityApplication {

    public static void main(String[] args) {
        SpringApplication.run(BulgarianRacingCommunityApplication.class, args);
    }

}
