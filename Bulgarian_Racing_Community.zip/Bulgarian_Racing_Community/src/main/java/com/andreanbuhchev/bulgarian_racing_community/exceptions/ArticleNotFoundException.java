package com.andreanbuhchev.bulgarian_racing_community.exceptions;

public class ArticleNotFoundException extends RuntimeException{
}
