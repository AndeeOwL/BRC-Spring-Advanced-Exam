package com.andreanbuhchev.bulgarian_racing_community.model.entity.enums;


public enum RoleEnum {
    ADMIN,USER
}
