package com.andreanbuhchev.bulgarian_racing_community;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulgarianRacingCommunityApplicationTests {

    @Test
    void contextLoads() {
    }

}
